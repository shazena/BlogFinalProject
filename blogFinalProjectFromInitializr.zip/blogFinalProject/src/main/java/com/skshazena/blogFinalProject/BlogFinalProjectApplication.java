package com.skshazena.blogFinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogFinalProjectApplication.class, args);
	}

}
