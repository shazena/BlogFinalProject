package com.skshazena.blogFinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
